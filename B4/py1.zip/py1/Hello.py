userName = 'Tran Ngoc The Anh'
print('ten nguoi dung la :', userName )
