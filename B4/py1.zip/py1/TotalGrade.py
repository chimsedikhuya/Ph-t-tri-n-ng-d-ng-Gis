studentName = 'Tran Ngoc The Anh'
gradeA = 8.0
gradeB = 8.6
gradeC = 10.0
totalGrade = 0.1*gradeC + 0.3*gradeB + 0.6*gradeA
print('sinh vien:',studentName,'co diem hoc phan la',totalGrade)