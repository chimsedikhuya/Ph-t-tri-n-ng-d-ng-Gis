print('ban muon mua bao nhieu ly tra sua?')
number = int(input('nhap vao so luong:'))
price = 35000
total = price*number
print('cua ban',number,'ly tra sua tran chau duong den het',total,'VND')
