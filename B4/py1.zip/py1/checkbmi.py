heightBMI = 1.65
weightBMI = 50
user1Height = 1.60
user1Weight = 52
user2Height = 1.72
user2Weight = 63
print('nguoi thu nhat khong du tieu chuan')
print('nguoi thu 2 du tieu chuan')
