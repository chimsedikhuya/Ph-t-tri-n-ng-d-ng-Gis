num1 = 2
num2 = 1

num = num1 - num2

print('vi',num,'la so duong nen so lon hon la',num1)