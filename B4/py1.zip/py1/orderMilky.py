print('ban muon mua bao nhieu ly tra sua tran chau duong den')
amout = 5
price = 100000
print('cua ban',amout, 'ly tran chau duong den tong cong het',price)