name = input('Nhap ten cua nguoi dung')
print('hello',name)