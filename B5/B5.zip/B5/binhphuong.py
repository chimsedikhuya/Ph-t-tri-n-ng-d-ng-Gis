num = int(input('Hay nhap vao so ban muon trong khoang tu 1 den 10:'))
sqr = int(num*num)

if(num < 10):
    print('binh phuong cua so ban nhap la:', sqr)
else: print('so ban nhap la sai')
