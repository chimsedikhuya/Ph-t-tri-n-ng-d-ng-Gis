mob = int(input('nhap vao thang sinh cua ban:'))

if (mob == 1 or mob ==2 or mob == 3):
    print('ban sinh vao mua xuan')
elif (mob == 4 or mob ==5 or mob == 6):
    print('ban sinh vao mua ha')
elif (mob == 7 or mob ==8 or mob == 9):
    print('ban sinh vao mua thu')
elif (mob == 10 or mob ==11 or mob == 12):
    print('ban sinh vao mua dong')
else: 
    print('thang sinh nhap khong dung')